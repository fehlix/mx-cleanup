/**********************************************************************
 *  mainwindow.h
 **********************************************************************
 * Copyright (C) 2018-2025 MX Authors
 *
 * Authors: Adrian
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/
#pragma once

#include <QButtonGroup>
#include <QCloseEvent>
#include <QMessageBox>
#include <QSettings>
#include <memory>

namespace Ui
{
class MainWindow;
}

enum class QuietMode
{
    No,
    Yes,
};

class MainWindow : public QDialog
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void pushAbout_clicked();
    void pushApply_clicked();
    void pushHelp_clicked();
    void pushKernel_clicked();
    void pushRTLremove_clicked();
    void pushUsageAnalyzer_clicked();

private:
    Ui::MainWindow *ui;
    std::unique_ptr<QSettings> settings;
    QString currentSettingsPath;
    QString shadowSettingsPath;
    QString currentUser;
    bool isArchLinux {false};
    bool manualRemovalInProgress {false};
    bool suppressUserSwitch {false};
    QString cmdOut(const QString &cmd, QuietMode quiet = QuietMode::No);
    bool helperProc(const QStringList &helperArgs, QuietMode quiet = QuietMode::No, QString *output = nullptr);
    bool helperExec(const QString &cmd, const QStringList &args = {}, QuietMode quiet = QuietMode::No,
                    QString *output = nullptr);
    QString helperOut(const QString &cmd, const QStringList &args = {}, QuietMode quiet = QuietMode::No);
    bool helperFlatpakCleanup(const QString &user, QuietMode quiet = QuietMode::No);
    quint64 helperDuSize(const QString &path, QuietMode quiet = QuietMode::No);
    static quint64 sumKiB(const QString &output);

    static void addGroupCheckbox(QLayout *layout, const QStringList &package, const QString &name, QStringList *list);
    static void selectRadioButton(class QGroupBox *groupbox, const QButtonGroup *group, int id);
    void loadOptions(bool settingsPreloaded = false);
    void loadSchedule(bool settingsPreloaded = false);
    void loadSettings();
    void removeKernelPackages(const QStringList &list);
    void removeManuals();
    void saveSchedule(const QString &cmd_str, const QString &period);
    void saveSettings();
    void setConnections();
    void setup();
    void startPreferredApp(const QStringList &apps);
    QString homeDirForUser(const QString &user) const;
    QString primaryGroupForUser(const QString &user) const;
    QString cronEntryBase(const QString &period) const;
    QString cronEntryPath(const QString &period, bool forWrite) const;
    QString currentUserSuffix() const;
    QString scriptFileBase() const;
    QString scriptFilePath(bool forWrite) const;
    QString settingsDirForUser(const QString &user) const;
    QString settingsFileForUser(const QString &user) const;
    void initializeSettingsForUser(const QString &user);
    void ensureSettingsOwnership(const QString &user, const QString &targetPath);
};
