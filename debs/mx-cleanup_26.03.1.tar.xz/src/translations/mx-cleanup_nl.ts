<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="184"/>
        <location filename="../mainwindow.cpp" line="1234"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <source>MX Cleanup</source>
        <translation>MX Opruimen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <source>Display help </source>
        <translation>Toon help</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <source>Help</source>
        <translation>Hulp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <source>About this application</source>
        <translation>Over deze toepassing</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <source>Main</source>
        <translation>Hoofd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <source>Purge residual configurations from removed packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <source>Tools</source>
        <translation>Gereedschap</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <source>Removal Tools</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation>MX-handleidingen voor andere talen dan de systeemstandaard verwijderen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1335"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <source>Apply</source>
        <translation>Toepassen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <source>Empty Trash</source>
        <translation>Prullenbak Legen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <source>Trash older than:</source>
        <translation>Afval ouder dan:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <source> days</source>
        <translation>dagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <source>All users</source>
        <translation>Alle gebruikers</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <source>Selected user</source>
        <translation>Geselecteerde gebruiker</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <source>Clear APT Cache</source>
        <translation>Ruim Apt Cache op</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <source>Old files</source>
        <translation>Oude bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <source>All files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Grafisch Gereedschap voor het Analyseren van Schijfgebruik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Schijfgebruik Analyse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <source>Schedule</source>
        <translation>Schema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <source>No automatic clean</source>
        <translation>Geen automatische schoonmaak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <source>At reboot</source>
        <translation>Bij herstarten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <source>Daily</source>
        <translation>Dagelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <source>Weekly</source>
        <translation>Wekelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <source>Monthly</source>
        <translation>Maandelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <source>Free Disk Space for User</source>
        <translation>Vrije Schijfruimte voor Gebruiker</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <source>Select user to repair</source>
        <translation>Selecteer een gebruiker voor reparatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <source>Select user:</source>
        <translation>Selecteer gebruiker:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <source>Delete Logs</source>
        <translation>Verwijder Logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <source>All logs</source>
        <translation>Alle logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <source>Old logs</source>
        <translation>Oude logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <source>Logs older than:</source>
        <translation>Logs ouder dan:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Ongebruikte wifi-stuurprogramma&apos;s verwijderen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <source>List and select kernels to remove</source>
        <translation>Lijst en selectie van te verwijderen kernels</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <source>Clean Flatpak</source>
        <translation>Schoonmaken Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <source>Remove unused runtimes</source>
        <translation>Ongebruikte looptijden verwijderen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <source>Clean Folders</source>
        <translation>Folders om te Schonen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <source>Not accessed for:</source>
        <translation>Niet toegankelijk voor:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <source>All (potentially dangerous)</source>
        <translation>Alle (potentieel gevaarlijk)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <source>Thumbnails</source>
        <translation>Thumbnails</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Remove Manuals</source>
        <translation>Handleidingen verwijderen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>No manuals to remove.</source>
        <translation>Geen handleidingen om te verwijderen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Removing packages, please wait</source>
        <translation>Pakketten worden verwijderd, even geduld alstublieft</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source> day</source>
        <translation>dag</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <location filename="../mainwindow.cpp" line="753"/>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="204"/>
        <source>Clean pacman cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Failed to create temporary cron file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="754"/>
        <source>Failed to create temporary script file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Failed to elevate privileges</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1222"/>
        <source>Done</source>
        <translation>Klaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1224"/>
        <source>Cleanup script will run at reboot</source>
        <translation>Opschoonscript wordt uitgevoerd bij opnieuw opstarten</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Cleanup command done</source>
        <translation>Opruim commando klaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1226"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB werd vrijgemaakt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1234"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1235"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1237"/>
        <source>Quick and safe removal of old files</source>
        <translation>Snelle en veilige verwijdering van oude bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1239"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1240"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1247"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1330"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Kernel momenteel in gebruik:&lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1333"/>
        <source>Remove selected</source>
        <translation>Verwijder geselecteerde</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1338"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Soortgelijke kernels die kunnen worden verwijderd:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1339"/>
        <source>Other kernels that can be removed:</source>
        <translation>Andere kernels die kunnen worden verwijderd:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1342"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Niets om te verwijderen.&lt;/b&gt; Kan kernel in gebruik niet verwijderen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1386"/>
        <source>Info</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1386"/>
        <source>No unused network drivers found to remove.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="71"/>
        <location filename="../about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Snel en veilig oude bestanden verwijderen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <location filename="../main.cpp" line="97"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>U lijkt ingelogd te zijn als root, gelieve uit te loggen en in te loggen als normale gebruiker om dit programma te gebruiken.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="98"/>
        <source>You must run this program with admin access.</source>
        <translation>Je moet dit programma uitvoeren met admin-toegang.</translation>
    </message>
</context>
</TS>