<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="184"/>
        <location filename="../mainwindow.cpp" line="1234"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <source>MX Cleanup</source>
        <translation>MX Porządki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <source>Display help </source>
        <translation>Wyświetl pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <source>About this application</source>
        <translation>O programie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <source>Main</source>
        <translation>Główne</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <source>Purge residual configurations from removed packages</source>
        <translation>Usuń pozostałe konfiguracje z usuniętych pakietów</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <source>Tools</source>
        <translation>Narzędzia</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <source>Removal Tools</source>
        <translation>Narzędzia do usuwania</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation>Usuń podręczniki MX dla języków innych niż domyślne języki systemowe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <source>About...</source>
        <translation>O...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <source>Quit application</source>
        <translation>Zakończ aplikację</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1335"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <source>Empty Trash</source>
        <translation>Opróżnij kosz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <source>Trash older than:</source>
        <translation>Usuń starsze niż:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <source> days</source>
        <translation>dni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <source>All users</source>
        <translation>Wszyscy użytkownicy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <source>Selected user</source>
        <translation>Wybrany użytkownik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <source>Clear APT Cache</source>
        <translation>Wyczyść pamięć podręczną APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <source>Old files</source>
        <translation>Stare pliki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Narzędzie graficzne do analizy wykorzystania dysku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Uruchom Analizator wykorzystania dysku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <source>Schedule</source>
        <translation>Harmonogram</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <source>No automatic clean</source>
        <translation>Nie czyść automatycznie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <source>At reboot</source>
        <translation>Podczas ponownego uruchamiania</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <source>Daily</source>
        <translation>Codziennie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <source>Weekly</source>
        <translation>Co tydzień</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <source>Monthly</source>
        <translation>Co miesiąc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <source>Free Disk Space for User</source>
        <translation>Zwolnij miejsce na dysku dla użytkownika</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <source>Select user to repair</source>
        <translation>Wybierz użytkownika do naprawy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <source>Select user:</source>
        <translation>Wybierz użytkownika:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <source>Delete Logs</source>
        <translation>Usuń dzienniki (logi)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <source>All logs</source>
        <translation>Wszystkie dzienniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <source>Old logs</source>
        <translation>Stare dzienniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <source>Logs older than:</source>
        <translation>Logi starsze niż:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Usuń nieużywane sterowniki WiFi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <source>List and select kernels to remove</source>
        <translation>Wyświetl listę i wybierz kernele do usunięcia</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <source>Clean Flatpak</source>
        <translation>Wyczyść Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <source>Remove unused runtimes</source>
        <translation>Usuń nieużywane środowiska wykonawcze</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <source>Clean Folders</source>
        <translation>Wyczyść foldery</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <source>Not accessed for:</source>
        <translation>Brak dostępu dla:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <source>Cache</source>
        <translation>Pamięć podręczna</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <source>All (potentially dangerous)</source>
        <translation>Wszystkie (potencjalnie niebezpieczne)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <source>Thumbnails</source>
        <translation>Miniatury</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Remove Manuals</source>
        <translation>Usuń podręczniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>No manuals to remove.</source>
        <translation>Brak podręczników do usunięcia.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Removing packages, please wait</source>
        <translation>Usuwanie pakietów, proszę czekać</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source> day</source>
        <translation>dzień</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <location filename="../mainwindow.cpp" line="753"/>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="204"/>
        <source>Clean pacman cache</source>
        <translation>Wyczyść pamięć podręczną pacmana</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Failed to create temporary cron file: %1</source>
        <translation>Nie udało się utworzyć tymczasowego pliku cron: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="754"/>
        <source>Failed to create temporary script file: %1</source>
        <translation>Nie udało się utworzyć tymczasowego pliku skryptu: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Failed to elevate privileges</source>
        <translation>Nie udało się podnieść uprawnień</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1222"/>
        <source>Done</source>
        <translation>Gotowe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1224"/>
        <source>Cleanup script will run at reboot</source>
        <translation>Skrypt czyszczący zostanie uruchomiony przy ponownym uruchomieniu systemu</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Cleanup command done</source>
        <translation>Wykonano polecenie czyszczenia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1226"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB zostało uwolnione</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1234"/>
        <source>About</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1235"/>
        <source>Version: </source>
        <translation>Wersja:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1237"/>
        <source>Quick and safe removal of old files</source>
        <translation>Szybkie i bezpieczne usuwanie starych plików</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1239"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Prawa autorskie © MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1240"/>
        <source>%1 License</source>
        <translation>%1 Licencja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1247"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1330"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Aktualnie używany kernel: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1333"/>
        <source>Remove selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1338"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Podobne kernele, które można usunąć:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1339"/>
        <source>Other kernels that can be removed:</source>
        <translation>Inne kernele, które można usunąć:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1342"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Nic do usunięcia.&lt;/b&gt; Nie można usunąć używanego kernela.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1386"/>
        <source>Info</source>
        <translation>Informacje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1386"/>
        <source>No unused network drivers found to remove.</source>
        <translation>Nie znaleziono nieużywanych sterowników sieciowych do usunięcia.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>License</source>
        <translation>Licencja</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="71"/>
        <location filename="../about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Dziennik zmian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Szybkie bezpieczne usuwanie starych plików</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <location filename="../main.cpp" line="97"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Wygląda na to, że jesteś zalogowany jako root, wyloguj się i zaloguj jako zwykły użytkownik, aby korzystać z tego programu.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="98"/>
        <source>You must run this program with admin access.</source>
        <translation>Musisz uruchomić ten program z uprawnieniami administratora.</translation>
    </message>
</context>
</TS>