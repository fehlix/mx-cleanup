<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fr_BE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="184"/>
        <location filename="../mainwindow.cpp" line="1222"/>
        <source>MX Cleanup</source>
        <translation>MX Nettoyage - MX Cleanup</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Display help </source>
        <translation>Afficher l’aide </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <source>About this application</source>
        <translation>À propos de cette application</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <source>Purge residual configurations from removed packages</source>
        <translation>Purger les configurations résiduelles des paquets supprimés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <source>Tools</source>
        <translation>Outils </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <source>Removal Tools</source>
        <translation>Outil de suppression</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation>Supprimer les manuels MX pour les langues autres que la langue par défaut du système</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <source>About...</source>
        <translation>À propos …</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <source>Quit application</source>
        <translation>Quitter l’application</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1323"/>
        <source>Close</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <source>Apply</source>
        <translation>Appliquer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>Empty Trash</source>
        <translation>Vider la corbeille</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <source>Trash older than:</source>
        <translation>Poubelle plus vieille que:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="895"/>
        <source> days</source>
        <translation> jours</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>All users</source>
        <translation>Tous•tes les utilisateurs•rices</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <source>Selected user</source>
        <translation>Utilisateur•rice sélectionné•e</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <source>Clear APT Cache</source>
        <translation>Vider le cache APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Old files</source>
        <translation>Anciens fichiers</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <source>All files</source>
        <translation>Tous les fichiers</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Outil graphique d’analyse de l’utilisation du disque</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Lancer l’analyse de l’utilisation du disque</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <source>Schedule</source>
        <translation>Programme</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>No automatic clean</source>
        <translation>Pas de nettoyage automatique</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>At reboot</source>
        <translation>Au redémarrage</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Daily</source>
        <translation>Quotidien</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Weekly</source>
        <translation>Hebdomadaire</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Monthly</source>
        <translation>Mensuel</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <source>Free Disk Space for User</source>
        <translation>Espace disque libre de l’utilisateur•rice</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <source>Select user to repair</source>
        <translation>Choisir l’utilisateur•rice à modifier ou à réparer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <source>Select user:</source>
        <translation>Choisir l’utilisateur•rice:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>Delete Logs</source>
        <translation>Supprimer les journaux - logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <source>All logs</source>
        <translation>Tous les journaux - logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <source>Old logs</source>
        <translation>Anciens journaux - logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <source>Logs older than:</source>
        <translation>Journaux - logs plus vieux que:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Supprimer les pilotes WiFi inutilisés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <source>List and select kernels to remove</source>
        <translation>Lister et sélectionner les noyaux à supprimer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <source>Clean Flatpak</source>
        <translation>Flatpak à nettoyer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <source>Remove unused runtimes</source>
        <translation>Suppression des runtimes « environnements d’exécution » inutilisés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <source>Clean Folders</source>
        <translation>Dossiers à nettoyer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <source>Not accessed for:</source>
        <translation>Non consulté depuis:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <source>All (potentially dangerous)</source>
        <translation>Tout (potentiellement dangereux)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Thumbnails</source>
        <translation>Images miniatures - thumbnails</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Remove Manuals</source>
        <translation>Supprimer les manuels</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>No manuals to remove.</source>
        <translation>Aucun manuel à supprimer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Removing packages, please wait</source>
        <translation>Suppression des paquets, veuillez patienter</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="895"/>
        <source> day</source>
        <translation> jour</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="733"/>
        <location filename="../mainwindow.cpp" line="746"/>
        <location filename="../mainwindow.cpp" line="912"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="204"/>
        <source>Clean pacman cache</source>
        <translation>Nettoyer le cache de pacman</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="734"/>
        <source>Failed to create temporary cron file: %1</source>
        <translation>Impossible de créer le fichier cron temporaire: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="747"/>
        <source>Failed to create temporary script file: %1</source>
        <translation>Impossible de créer le fichier script temporaire: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="912"/>
        <source>Failed to elevate privileges</source>
        <translation>L’élévation des privilèges a échoué</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1210"/>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1212"/>
        <source>Cleanup script will run at reboot</source>
        <translation>Le script de nettoyage s’exécutera au redémarrage</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1213"/>
        <source>Cleanup command done</source>
        <translation>Commande de nettoyage exécutée</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1214"/>
        <source>%1 MiB were freed</source>
        <translation>%1 Mio sont de nouveau disponibles</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1222"/>
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1223"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Quick and safe removal of old files</source>
        <translation>Suppression rapide et sûre des anciens fichiers</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1227"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1228"/>
        <source>%1 License</source>
        <translation>%1 Licence</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1235"/>
        <source>%1 Help</source>
        <translation>%1 Aide</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1318"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Noyau utilisé actuellement: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1321"/>
        <source>Remove selected</source>
        <translation>Supprimer le(s) sélectionné(s)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1326"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Noyaux similaires qui peuvent être supprimés:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1327"/>
        <source>Other kernels that can be removed:</source>
        <translation>Autres noyaux qui peuvent être supprimés:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1330"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Rien à supprimer.&lt;/b&gt; Impossible de retirer le noyau en cours d’utilisation.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1374"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1374"/>
        <source>No unused network drivers found to remove.</source>
        <translation>Aucun pilote réseau inutilisé à supprimer.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="71"/>
        <location filename="../about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Journal des modifications</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Suppression rapide et sûre des anciens fichiers</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <location filename="../main.cpp" line="97"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Vous êtes apparemment connecté en tant que root, veuillez vous déconnecter et vous connecter en tant qu’utilisateur•rice normal•e pour utiliser ce programme.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="98"/>
        <source>You must run this program with admin access.</source>
        <translation>Vous devez exécuter ce programme avec un accès administrateur•rice.</translation>
    </message>
</context>
</TS>