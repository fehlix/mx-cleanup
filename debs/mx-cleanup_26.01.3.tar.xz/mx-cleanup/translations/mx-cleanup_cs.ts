<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="cs">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="184"/>
        <location filename="../mainwindow.cpp" line="1218"/>
        <source>MX Cleanup</source>
        <translation>MX Cleanup</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Display help </source>
        <translation>Zobrazit nápovědu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <source>About this application</source>
        <translation>O této aplikaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <source>Main</source>
        <translation>Hlavní</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <source>Purge residual configurations from removed packages</source>
        <translation>Odstranit zbytky konfigurací odinstalovaných balíčků</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <source>Tools</source>
        <translation>Nástroje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <source>Removal Tools</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <source>About...</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1319"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>Empty Trash</source>
        <translation>Vysypat Koš</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <source>Trash older than:</source>
        <translation>Smazané položky starší než:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="891"/>
        <source> days</source>
        <translation>dní</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>All users</source>
        <translation>Všichni uživatelé</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <source>Selected user</source>
        <translation>Vybraný uživatel</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <source>Clear APT Cache</source>
        <translation>Vyčistit mezipaměť APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Old files</source>
        <translation>Staré soubory</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <source>All files</source>
        <translation>Všechny soubory</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Grafický nástroj pro analýzu využití disku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Spustit analýzu využití disku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <source>Schedule</source>
        <translation>Plán</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>No automatic clean</source>
        <translation>Bez automatického čištění</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>At reboot</source>
        <translation>Při restartu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Daily</source>
        <translation>Denní</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Weekly</source>
        <translation>Týdenní</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Monthly</source>
        <translation>Měsíční</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <source>Free Disk Space for User</source>
        <translation>Uvolnit místo na disku uživatele</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <source>Select user to repair</source>
        <translation>Vybrat uživatele k opravě</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <source>Select user:</source>
        <translation>Vyberte uživatele:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>Delete Logs</source>
        <translation>Smazat Log soubory</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <source>All logs</source>
        <translation>Všechny logy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <source>Old logs</source>
        <translation>Staré logy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <source>Logs older than:</source>
        <translation>Záznamy starší než:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Odstranění nepoužívaných ovladačů WiFi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <source>List and select kernels to remove</source>
        <translation>Seznam Linux jáder pro odebrání</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <source>Clean Flatpak</source>
        <translation>Flatpaky k vyčištění</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <source>Remove unused runtimes</source>
        <translation>Odebrat nevyužité runtimy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <source>Clean Folders</source>
        <translation>Složky k vyčištění</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <source>Not accessed for:</source>
        <translation>Nezpřístupněno pro:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <source>Cache</source>
        <translation>Mezipaměť</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <source>All (potentially dangerous)</source>
        <translation>Vše (potencionálně nebezpečné) </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Thumbnails</source>
        <translation>Miniatury</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Remove Manuals</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>No manuals to remove.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Removing packages, please wait</source>
        <translation>Odebírání balíčků, čekejte prosím</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="891"/>
        <source> day</source>
        <translation>den</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="729"/>
        <location filename="../mainwindow.cpp" line="742"/>
        <location filename="../mainwindow.cpp" line="908"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="204"/>
        <source>Clean pacman cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="730"/>
        <source>Failed to create temporary cron file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>Failed to create temporary script file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="908"/>
        <source>Failed to elevate privileges</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1206"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1208"/>
        <source>Cleanup script will run at reboot</source>
        <translation>Při restartu se spustí čisticí skript</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1209"/>
        <source>Cleanup command done</source>
        <translation>Příkaz vyčištění byl dokončen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1210"/>
        <source>%1 MiB were freed</source>
        <translation>Bylo uvolněno %1 MiB</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1218"/>
        <source>About</source>
        <translation>O aplikaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1219"/>
        <source>Version: </source>
        <translation>Verze:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1221"/>
        <source>Quick and safe removal of old files</source>
        <translation>Rychlé a bezpečné odstranění starých souborů</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1223"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1224"/>
        <source>%1 License</source>
        <translation>Licence %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1231"/>
        <source>%1 Help</source>
        <translation>Nápověda %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1314"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Momentálně používané jádro: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1317"/>
        <source>Remove selected</source>
        <translation>Odebrat označené</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1322"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Podobné jádra, které je možné odstranit:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1323"/>
        <source>Other kernels that can be removed:</source>
        <translation>Jiné jádra, které je možné odstranit:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1326"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Nic k odstranění.&lt;/b&gt; Nelze odebrat jádro, které je akt. používané.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1370"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1370"/>
        <source>No unused network drivers found to remove.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="71"/>
        <location filename="../about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Protokol změn</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Bezpečné odebrání zastaralých souborů</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <location filename="../main.cpp" line="97"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Spuštěno pod účtem root-a, odhlašte se a přihlašte jako bězný uživatel.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="98"/>
        <source>You must run this program with admin access.</source>
        <translation>Tento program musíte spustit s oprávněním správce.</translation>
    </message>
</context>
</TS>