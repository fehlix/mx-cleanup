# Repository Guidelines

## Project Structure & Module Organization
mx-cleanup is a Qt6/C++ desktop application. Core sources (`main.cpp`, `mainwindow.*`, `about.*`) live in the repository root alongside `mainwindow.ui` and `images.qrc`. Reusable constants and environment helpers sit in `common.h`. Assets such as icons are under `images/`, while localized strings live in `translations/`. Debian packaging rules and helper policies reside in `debian/` and `scripts/`.

## Build, Test, and Development Commands
Preferred workflow uses CMake with Ninja. Run `./build.sh` for a Release build placed at `build/mx-cleanup`; add `-d` for Debug or `--clang` to validate with Clang. If you need a clean slate, call `./build.sh --clean` before rebuilding. Developers who bypass the wrapper can run `cmake -G Ninja -B build` followed by `cmake --build build --parallel`. To produce Debian artifacts, execute `./build.sh --debian`, which stages packages under `debs/`.

## Coding Style & Naming Conventions
Source files follow Qt’s default style: four-space indents, braces on their own lines, and CamelCase class or enum names (`MainWindow`, `CleanupAction`). Qt signals/slots and helper functions use lowerCamelCase. Keep includes ordered Qt-first, then system headers. Prefer Qt containers (`QString`, `QVector`) and maintain existing header guards (`#pragma once`). Avoid introducing unused `using` directives.

## Testing Guidelines
There is no automated test suite; smoke-test manually after each change. Launch the binary from `build/mx-cleanup` to verify critical flows: scan, cleanup, dry-run prompts, and elevated execution. Check locale coverage by exporting `LANG=es_ES.UTF-8` (or another available `.ts`) before running to ensure UI strings load correctly.

## Commit & Pull Request Guidelines
Recent history favors concise, imperative commit subjects (`Fix cleanup count`, `New build`). Keep commits focused and mention related issues or packaging tickets in the body. Pull requests should describe the change scope, highlight any UI impacts, and attach before/after screenshots when user-visible. List the commands you ran (build, manual checks) and call out translation or packaging updates that reviewers should double-check.

## Packaging & Localization
When adjusting `debian/*` or policy files, mirror changes in `build.sh --debian` expectations. Update translations with the CMake target (`cmake --build build --target translations`) and commit regenerated `.qm` files.
